package cl.nooc.narutocharacter.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import cl.nooc.narutocharacter.R;
import cl.nooc.narutocharacter.databinding.FragmentResultsBinding;
import cl.nooc.narutocharacter.modelo.Personaje;
import io.github.muddz.styleabletoast.StyleableToast;

public class ResultsFragment extends Fragment {

    private FragmentResultsBinding binding;
    private List<Personaje> lista;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentResultsBinding.inflate(inflater, container, false);

        int resultado = getArguments().getInt("resultado");

        llenarLista();
        Log.d("resultado", String.valueOf(resultado));
        if (resultado == 10) {
            //Sakura
            binding.ivResultado.setImageResource(lista.get(8).getImagen());
            binding.tvResultado.setText(lista.get(8).getNombre());
        }
        else if (resultado >= 11 && resultado <= 18) {
            //Hinata
            binding.ivResultado.setImageResource(lista.get(1).getImagen());
            binding.tvResultado.setText(lista.get(1).getNombre());
        }
        else if (resultado >= 19 && resultado <= 23) {
            //Kakashi
            binding.ivResultado.setImageResource(lista.get(4).getImagen());
            binding.tvResultado.setText(lista.get(4).getNombre());
        }
        else if (resultado >= 24 && resultado <= 26) {
            //Itachi
            binding.ivResultado.setImageResource(lista.get(2).getImagen());
            binding.tvResultado.setText(lista.get(2).getNombre());
        }
        else if (resultado == 27) {
            //Gaara
            binding.ivResultado.setImageResource(lista.get(0).getImagen());
            binding.tvResultado.setText(lista.get(0).getNombre());
        }
        else if (resultado == 28) {
            //Naruto
            binding.ivResultado.setImageResource(lista.get(6).getImagen());
            binding.tvResultado.setText(lista.get(6).getNombre());
        }
        else if (resultado == 29) {
            //Obito
            binding.ivResultado.setImageResource(lista.get(7).getImagen());
            binding.tvResultado.setText(lista.get(7).getNombre());
        }
        else if (resultado == 30) {
            //Sasuke
            binding.ivResultado.setImageResource(lista.get(10).getImagen());
            binding.tvResultado.setText(lista.get(10).getNombre());
        }
        else if (resultado >= 31 && resultado <= 32) {
            //Jiraiya
            binding.ivResultado.setImageResource(lista.get(3).getImagen());
            binding.tvResultado.setText(lista.get(3).getNombre());
        }
        else if (resultado >= 33 && resultado <= 34) {
            //Sasori
            binding.ivResultado.setImageResource(lista.get(9).getImagen());
            binding.tvResultado.setText(lista.get(9).getNombre());
        }
        else if (resultado >= 35 && resultado <= 36) {
            //Minato
            binding.ivResultado.setImageResource(lista.get(5).getImagen());
            binding.tvResultado.setText(lista.get(5).getNombre());
        }
        else {
            binding.ivResultado.setImageResource(lista.get(11).getImagen());
            binding.tvResultado.setText(lista.get(11).getNombre());
        }

        binding.btnVolver.setOnClickListener(v -> {
            StyleableToast.makeText(getContext(), "Volviendo✍️(◔◡◔)", Toast.LENGTH_LONG,
                    R.style.mytoast).show();
            Navigation.findNavController(v).navigate(R.id.action_resultsFragment_to_homeFragment);
        });

        return binding.getRoot();
    }

    private void llenarLista() {
        lista = new ArrayList<>();
        lista.add(new Personaje("Gaara", R.drawable.gaara));
        lista.add(new Personaje("Hinata", R.drawable.hinata));
        lista.add(new Personaje("Itachi", R.drawable.itachi));
        lista.add(new Personaje("Jiraiya", R.drawable.jiraiya));
        lista.add(new Personaje("Kakashi", R.drawable.kkshi));
        lista.add(new Personaje("Minato", R.drawable.minato));
        lista.add(new Personaje("Naruto", R.drawable.naruto));
        lista.add(new Personaje("Obito", R.drawable.obito));
        lista.add(new Personaje("Sakura", R.drawable.sakura));
        lista.add(new Personaje("Sasori", R.drawable.sasori));
        lista.add(new Personaje("Sasuke", R.drawable.sasuke));
        lista.add(new Personaje("Shikamaru", R.drawable.shikamaru));
    }
}