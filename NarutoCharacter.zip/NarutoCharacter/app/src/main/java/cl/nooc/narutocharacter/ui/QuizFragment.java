package cl.nooc.narutocharacter.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cl.nooc.narutocharacter.R;
import cl.nooc.narutocharacter.databinding.FragmentQuizBinding;
import cl.nooc.narutocharacter.modelo.Preguntas;

public class QuizFragment extends Fragment {

    private FragmentQuizBinding binding;
    private List<Preguntas> lista;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentQuizBinding.inflate(inflater, container, false);

        if(getArguments() == null){
            int pos = 10;
            int puntaje = 0;
            llenarLista();
            click(lista, pos, puntaje);
        } else {
            int pos = getArguments().getInt("posicion");

            lista = (List<Preguntas>) getArguments().getSerializable("lista");
            int puntaje = getArguments().getInt("puntos");
            click(lista, pos, puntaje);
        }

        return binding.getRoot();
    }

    private void llenarLista(){
        lista = new ArrayList<>();
        lista.add(new Preguntas("¿Te gusta pintarte las uñas?",
                "Sólo de vez en cuando",
                "Si, a diario",
                "No, para nada",
                "No lo sé"));
        lista.add(new Preguntas("¿Qué harías si aparece tu crush?",
                "Le pido a un compañero que lo vaya a buscar por mí",
                "Me escondo y lo observo",
                "No hago nada, soy una planta",
                "Espero a que me golpee para ver si le agrado o no"));
        lista.add(new Preguntas("Me defino como una persona:",
                "Gruñona",
                "Alegre",
                "Triste",
                "Tímid@"));
        lista.add(new Preguntas("Mi primer beso fue con:",
                "Qué te importa￣へ￣",
                "Nadie, aún no lo he dado",
                "Con mi primer amor",
                "Mi rival"));
        lista.add(new Preguntas("¿Tienes mascotas?",
                "No, son mucho trabajo",
                "Adoptar huérfanos peligrosos, ¿cuenta?",
                "Si, me encantan",
                "No sé que son"));
        lista.add(new Preguntas("¿Cuál es tu comida favorita o la más parecida?",
                "Algo dulce",
                "Huevos",
                "Venganza",
                "Ramen/Fideos"));
        lista.add(new Preguntas("Mis conocidos creo que me consideran:",
                "Alguien que sólo existe",
                "Un payaso",
                "Una ayuda",
                "Su peor pesadilla"));
        lista.add(new Preguntas("¿Alguna vez han pensado que estás muert@?",
                "No...¿Estás bien?",
                "Si, todo el tiempo",
                "Sólo una vez",
                "Para nada, les encantaría"));
        lista.add(new Preguntas("¿Cuál sería tu día ideal?",
                "Si lo paso con mi crush, es mi día ideal",
                "Un día donde pueda molestar a mis amigos",
                "Sólo me importa volver al pasado",
                "Uno donde no tenga que hacer nada"));
        lista.add(new Preguntas("¿Cómo es tu relación con tu mejor amigo/amiga?",
                "Cada vez que nos vemos peleamos",
                "Pésima, no tengo ಥ_ಥ",
                "Muy bien, parecemos herman@s",
                "No estoy segur@ si sabe que es mi mejor amigo/amiga"));
    }

    private boolean isFin(List<Preguntas> l, int pos){
        if(pos == 1 && l.size() == pos){
            return true;
        }

        return false;
    }

    private void generarPregunta(List<Preguntas> lista){
        Collections.shuffle(lista);

        binding.tvPregunta.setText(lista.get(0).getPregunta());
        binding.tvResp1.setText(lista.get(0).getAlt1());
        binding.tvResp2.setText(lista.get(0).getAlt2());
        binding.tvResp3.setText(lista.get(0).getAlt3());
        binding.tvResp4.setText(lista.get(0).getAlt4());
    }

    private void click(List<Preguntas> lista, int pos, int puntaje){
        Log.d("posicion", String.valueOf(pos));
        Log.d("ptje", String.valueOf(puntaje));
        Bundle bundle = new Bundle();
        if(!isFin(lista, pos)) {
            generarPregunta(lista);
            binding.tvResp1.setOnClickListener(v -> {
                int ptje = puntaje + 1;
                int posi = pos - 1;
                lista.remove(0);
                bundle.putInt("puntos", ptje);
                bundle.putInt("posicion", posi);
                bundle.putSerializable("lista", (Serializable) lista);

                Navigation.findNavController(v).navigate(R.id.action_quizFragment_self, bundle);
            });
            binding.tvResp2.setOnClickListener(v -> {
                int ptje = puntaje + 2;
                int posi = pos - 1;
                lista.remove(0);
                bundle.putInt("puntos", ptje);
                bundle.putInt("posicion", posi);
                bundle.putSerializable("lista", (Serializable) lista);

                Navigation.findNavController(v).navigate(R.id.action_quizFragment_self, bundle);
            });
            binding.tvResp3.setOnClickListener(v -> {
                int ptje = puntaje + 3;
                int posi = pos - 1;
                lista.remove(0);
                bundle.putInt("puntos", ptje);
                bundle.putInt("posicion", posi);
                bundle.putSerializable("lista", (Serializable) lista);

                Navigation.findNavController(v).navigate(R.id.action_quizFragment_self, bundle);
            });
            binding.tvResp4.setOnClickListener(v -> {
                int ptje = puntaje + 4;
                int posi = pos - 1;
                lista.remove(0);
                bundle.putInt("puntos", ptje);
                bundle.putInt("posicion", posi);
                bundle.putSerializable("lista", (Serializable) lista);

                Navigation.findNavController(v).navigate(R.id.action_quizFragment_self, bundle);
            });
        } else {
            generarPregunta(lista);
            binding.tvResp1.setOnClickListener(v -> {
                int ptje = puntaje + 1;
                bundle.putInt("resultado",ptje);
                Navigation.findNavController(v).navigate(R.id.action_quizFragment_to_resultsFragment, bundle);
            });
            binding.tvResp2.setOnClickListener(v -> {
                int ptje = puntaje + 2;
                bundle.putInt("resultado",ptje);
                Navigation.findNavController(v).navigate(R.id.action_quizFragment_to_resultsFragment, bundle);
            });
            binding.tvResp3.setOnClickListener(v -> {
                int ptje = puntaje + 3;
                bundle.putInt("resultado",ptje);
                Navigation.findNavController(v).navigate(R.id.action_quizFragment_to_resultsFragment, bundle);
            });
            binding.tvResp4.setOnClickListener(v -> {
                int ptje = puntaje + 4;
                bundle.putInt("resultado",ptje);
                Navigation.findNavController(v).navigate(R.id.action_quizFragment_to_resultsFragment, bundle);
            });
        }

    }
}