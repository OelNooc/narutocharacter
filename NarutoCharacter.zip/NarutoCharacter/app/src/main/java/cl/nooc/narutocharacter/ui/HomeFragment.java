package cl.nooc.narutocharacter.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import cl.nooc.narutocharacter.R;
import cl.nooc.narutocharacter.databinding.FragmentHomeBinding;
import io.github.muddz.styleabletoast.StyleableToast;

public class HomeFragment extends Fragment {

   private FragmentHomeBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);

        Animation animas = AnimationUtils.loadAnimation(getContext(), R.anim.aparecer);

        binding.tvHome.setAnimation(animas);

        new Handler().postDelayed(() -> {
            StyleableToast.makeText(getContext(), "Bienvenid@ o(￣▽￣)ｄ", Toast.LENGTH_LONG,
                    R.style.mytoast).show();
            Navigation.findNavController(getView()).navigate(R.id.action_homeFragment_to_quizFragment);
        }, 6000);

        return binding.getRoot();
    }
}